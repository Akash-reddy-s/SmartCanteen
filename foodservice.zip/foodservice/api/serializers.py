from rest_framework import serializers
from .models import Restaurant, FoodItem, CartItem
from .models import Wallet

# Food serializer for both full display and nested use
class FoodItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = FoodItem
        fields = ['id', 'name', 'price']

# Restaurant serializer
class RestaurantSerializer(serializers.ModelSerializer):
    class Meta:
        model = Restaurant
        fields = '__all__'

# Cart serializer with readable item and writable item_id
class CartItemSerializer(serializers.ModelSerializer):
    item = FoodItemSerializer(read_only=True)
    item_id = serializers.PrimaryKeyRelatedField(
        queryset=FoodItem.objects.all(),
        source='item',
        write_only=True
    )

    class Meta:
        model = CartItem
        fields = ['id', 'session_id', 'item', 'item_id', 'quantity']

class WalletSerializer(serializers.ModelSerializer):
    class Meta:
        model = Wallet
        fields = ['id', 'session_id', 'balance']